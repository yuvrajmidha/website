import defination from "./definations"
import servicelevels from "./servicelevels"

module.exports.defination = defination
module.exports.servicelevels = servicelevels