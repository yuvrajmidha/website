export const ICONS = [
  {
    id: 1,
    image: "assets/shapes/Phone.svg",
    imageAlt: "Company Logo",
  },

  {
    id: 2,
    image: "assets/shapes/Mail.svg",
    imageAlt: "Company Logo",
  },

  {
    id: 3,
    image: "assets/shapes/Location.svg",
    imageAlt: "Company Logo",
  },
];
