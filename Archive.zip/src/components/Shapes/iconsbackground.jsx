export const ICONSBACKGROUND = [
  {
    id: 1,
    image: "assets/shapes/Background1.svg",
    imageUrl:
      "https://www.bgunifiedsolutions.net/wp-content/uploads/2019/03/Vocus.png",
    imageAlt: "Company Logo",
  },

  {
    id: 2,
    image: "assets/shapes/Background2.svg",
    imageAlt: "Company Logo",
  },

  {
    id: 3,
    image: "assets/shapes/Background3.svg",
    imageAlt: "Company Logo",
  },

  {
    id: 4,
    image: "assets/shapes/Background4.svg",
    imageAlt: "Company Logo",
  },

  {
    id: 5,
    image: "assets/shapes/Background5.svg",
    imageAlt: "Company Logo",
  },

  {
    id: 6,
    image: "assets/shapes/Background6.svg",
    imageAlt: "Company Logo",
  },

  {
    id: 7,
    image: "assets/shapes/Background7.svg",
    imageAlt: "Company Logo",
  },

  {
    id: 8,
    image: "assets/shapes/Background8.svg",
    imageAlt: "Company Logo",
  },

  {
    id: 9,
    image: "assets/shapes/Background9.svg",
    imageAlt: "Company Logo",
  },

  {
    id: 10,
    image: "assets/shapes/Background10.svg",
    imageAlt: "Company Logo",
  },

  {
    id: 11,
    image: "assets/shapes/Background11.svg",
    imageAlt: "Company Logo",
  },

  {
    id: 12,
    image: "assets/shapes/Background12.svg",
    imageAlt: "Company Logo",
  },

  {
    id: 13,
    image: "assets/shapes/Background13.svg",
    imageAlt: "Company Logo",
  },

  {
    id: 14,
    image: "../../static/Background14.svg",
    imageAlt: "Company Logo",
  },

  {
    id: 15,
    image: "assets/shapes/Background15.svg",
    imageAlt: "Company Logo",
  },

  {
    id: 16,
    image: "assets/shapes/Background16.svg",
    imageAlt: "Company Logo",
  },
];
