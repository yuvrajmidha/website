
const articles = [

    {
        index: 1,
        type: "Blog",
        category: "UX Design",
        title: "Simple Easy and Quick, Don't Make Me Think",
        date: "October 2020",
        by: "Yuvraj Midha",
        avatar: "/assets/images/team/yuvraj.jpg",
        image: "https://media-exp1.licdn.com/dms/image/C5112AQGwVDA9axrryA/article-cover_image-shrink_600_2000/0/1574256672318?e=1643241600&v=beta&t=aB6rgbWaw5wAlZ3LAKs_9SRsMdrtv2iMTWywYFEzrgo",
        tags: ["Business", "Design Thinking"],
        link: "simple-easy-and-quick-dont-make-me-think",
        meta: "This is the meta write anything here that is useful"
        // logo: "https://media-exp1.licdn.com/dms/image/C5112AQGwVDA9axrryA/article-cover_image-shrink_600_2000/0/1574256672318?e=1643241600&v=beta&t=aB6rgbWaw5wAlZ3LAKs_9SRsMdrtv2iMTWywYFEzrgo",
    },
]


export default articles