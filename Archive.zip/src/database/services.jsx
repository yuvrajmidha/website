import sections from '../pageBuilder/pages/solutions/index'

const services = {
    "logo-design": {
        title: "Logo Design",
        category: "Branding",
        tags: ["application", "app", "dev", "development", "scalability", "platform", "independence", "client", "flexibility"],
    },
    "product-labels": {
        title: "Logo Design",
        category: "Branding",
        tags: ["application", "app", "dev", "development", "scalability", "platform", "independence", "client", "flexibility"],
    },
    "social-media": {
        title: "Logo Design",
        category: "Branding",
        tags: ["application", "app", "dev", "development", "scalability", "platform", "independence", "client", "flexibility"],
    },
    "style-guides": {
        title: "Logo Design",
        category: "Branding",
        tags: ["application", "app", "dev", "development", "scalability", "platform", "independence", "client", "flexibility"],
    },
    "research-and-strategy":{
        title: "Reasearch & Strategy",
        category: "UI/UX Design",
        tags: []
    },
    "web-and-mobile-design":{
        title: "Web & Mobile Design",
        category: "UI/UX Design",
        tags: []
    },
    "visual-design":{
        title: "Visual Design",
        category: "UI/UX Design",
        tags: []
    },
    "prototyping":{
        title: "Prototyping & Testing",
        category: "UI/UX Design",
        tags: []
    },
    "web-app":{
        title: "Web Applications",
        category: "Development",
        tags: []
    },
    "saas":{
        title: "SaaS Development",
        category: "Development",
        tags: []
    },
    "e-commerce":{
        title: "E-Commerce",
        category: "Development",
        tags: []
    },
    "technical-seo":{
        title: "Technical SEO",
        category: "Development",
        tags: []
    },

   
  
}

export default services